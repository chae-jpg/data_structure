# Code 1
- Introduction
This code transposes the given matrix B. The transpose matrix of B is saved as matrix Bt.
Then, it transforms sparse matrix to dense matrix, and prints both of them. You can find out it works well.
- How to run the code
You can just open this file with your IDE, and run it.
- How to adjust parameters
If you want to change values about the size of the matrix (row and column size, maximum terms), you can change the line 3 ~ 5. THis line defines the number of rows, columns, and maximum terms of the matrix.
If you want to change the value of matrix B, you can fix line 21. This line assigns the matrix B.

# Code 2
- Introduction 
This code generates 3d array by dynamic memory allocation. And then, it set the value inside the array. Finally, it operates summation between matrix A and B(B = A + B), and prints the result of the operation(matrix B). After all these things end, it sets the pointers free.
- How to run the code
You can just open this file with your IDE, and run it.
- How to adjust parameters
Basically, this code generates n x n x n size (default: 3x3x3) array. If you want to change the value of n, you can change line 4. This line defines the size of n.
And, if you want to change the value inside the array, then you can change line 51 ~ 52. This line assigns the value to the array.
