# Code 2
- Introduction
This code returns new list c, which is list a and b merged in an ascending order.
- How to run the code
You can just open this file with your IDE, and run it.
- How to adjust parameters
If you want to change the elements inside the list a and b, then you can fix it in the main function.

# Code 3
- Introduction
This code implemented all functions that are included in List ADT, but in the version that the ListType also includes tail pointer.
- How to run the code
You can just open this file with your IDE, and run it.
- How to adjust parameters
If you want to change the elements inside the list1, then you can fix it in the main function.


